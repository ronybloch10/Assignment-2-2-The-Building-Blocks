//Select elements from the html 
const frog = document.getElementById("frog");
const aligator = document.getElementById("aligator");
const count = document.getElementById("count");

//the class animation defined in the style.css and the remove option is to stop the animation at an interval of 500
function jump() {
  frog.classList.add("jump-animation");
  setTimeout(() =>
    frog.classList.remove("jump-animation"), 500);
}
//the following defines that any key pressed will make the frog jump, since we have not defined any special key under the () and what it does by adding the jump
document.addEventListener('keypress', () => {
  //the following line prevents the frog to jump again before it reaches the base.
  if (!frog.classList.contains('jump-animation')) {
    jump();
  }
});
//defining the colision detection, so that the game stops and the apert comes up on the screen right after
setInterval(() => {
  count.innerText++;
  const frogTop = parseInt(window.getComputedStyle(frog)
    .getPropertyValue('top'));
  const aligatorLeft = parseInt(window.getComputedStyle(aligator)
    .getPropertyValue('left'));
//the next one below hides the aligator if it passes the border, thus your characters do not move outside the game area. If value is negative, does not display, otherwise, it shows on the screen
  if (aligatorLeft < 0) {
    aligator.style.display = 'none';
  } else {
    aligator.style.display = '';
  }
//that defines your alert with your score and if you want to restart the game
  if (aligatorLeft < 50 && aligatorLeft > 0 && frogTop > 150) {
    alert("You got a score of: " + count.innerText +
      "\n\nPlay again?");
    location.reload();
  }
}, 50);
