// JavaScript source code
function updateText(){
	document.getElementById("heading").innerHTML = "JavaScript is awesome!";
}